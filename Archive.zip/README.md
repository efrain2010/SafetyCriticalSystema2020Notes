# Safety Critical Systema 2020 Notes
